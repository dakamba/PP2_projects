print("Hello, Python!")

x = 10
if x > 5:
    print("x is greater than 5")

y = 3
if y == 3:
    print("y is 3")
else:
    print("y is not 3")

# mini task
a = 7
b = 12
if a > b:
    print("a is bigger")
else:
    print("b is bigger or equal")

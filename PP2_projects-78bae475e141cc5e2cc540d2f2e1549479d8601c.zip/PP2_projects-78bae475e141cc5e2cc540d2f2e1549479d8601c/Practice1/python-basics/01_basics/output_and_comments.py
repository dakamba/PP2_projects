print("Output examples")
print(10)
print(10 + 5)

name = "Daulet"
age = 17

print("My name is", name)
print("Age:", age)

# using separators
print("A", "B", "C", sep="-")
print("Line 1\nLine 2")

# mini task
city = "Almaty"
print(name, "lives in", city)
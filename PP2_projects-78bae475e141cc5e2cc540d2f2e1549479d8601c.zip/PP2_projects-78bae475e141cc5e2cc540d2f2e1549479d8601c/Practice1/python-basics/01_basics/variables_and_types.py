a = 5
b = 2.5
c = "hello"
d = True

print(a, type(a))
print(b, type(b))
print(c, type(c))
print(d, type(d))

# variable can change type
x = 100
print("x:", x, type(x))
x = "now string"
print("x:", x, type(x))

# mini task
item = "apple"
count = 3
price = 120.5
print("item:", item, "| count:", count, "| price:", price)

text = "Python"

print(text)
print("len:", len(text))
print("first:", text[0])
print("last:", text[-1])

print("slice 0:3 =", text[0:3])
print("slice 2: =", text[2:])
print("slice :4 =", text[:4])

msg = "  hello world  "
print(msg.strip())
print(msg.upper())
print(msg.replace("world", "Python"))

name = "Daulet"
age = 17
print("My name is " + name)
print(f"I am {age} years old")

# mini task
word = "programming"
print(word[0], word[-1], len(word))

x = 10
y = 3

print("x + y =", x + y)
print("x - y =", x - y)
print("x * y =", x * y)
print("x / y =", x / y)
print("x // y =", x // y)
print("x % y =", x % y)
print("x ** y =", x ** y)

n1 = "25"
n2 = "3.14"

i = int(n1)
f = float(n2)

print(i, type(i))
print(f, type(f))

print("i + 5 =", i + 5)
print("f + 1 =", f + 1)

z = 7.9
print(int(z))  # 7

# mini task
s = "100"
result = int(s) + 200
print(result)

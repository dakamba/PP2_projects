# Python Basics

Practice repo for Python fundamentals:
- syntax, output, comments
- variables, data types
- numbers, casting
- strings
- booleans, operators

Each file contains small examples and mini tasks.
